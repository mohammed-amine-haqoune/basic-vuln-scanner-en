#!/usr/bin/env python3
"""
vulnscan.py — Basic HTTP header & misconfiguration scanner (English-only).

Features:
- Checks common security headers and basic cookie flags
- Notes possible information leaks (Server, X-Powered-By)
- Supports single URL or a list, with simple threading
- Output: pretty (text), JSON, or CSV
"""
from __future__ import annotations

import argparse
import concurrent.futures as cf
import csv
import json
import sys
import time
from dataclasses import dataclass, asdict
from http.cookies import SimpleCookie
from typing import Dict, Iterable, List, Optional, Tuple
from urllib.parse import urlparse

import requests

DEFAULT_TIMEOUT = 10
USER_AGENT = "basic-vuln-scanner/1.0"

SECURITY_HEADERS = [
    "Strict-Transport-Security",
    "Content-Security-Policy",
    "X-Content-Type-Options",
    "X-Frame-Options",
    "Referrer-Policy",
    "Permissions-Policy",
    "X-XSS-Protection",  # deprecated
]

@dataclass
class Finding:
    key: str          # header name, 'Cookie:<name>', etc.
    ok: bool          # True when compliant/informational, False when problematic
    severity: str     # "low", "medium", "high", "info"
    message: str      # human-readable explanation

@dataclass
class ScanResult:
    url: str
    status: Optional[int]
    final_url: Optional[str]
    https: bool
    redirects: int
    elapsed_ms: Optional[int]
    findings: List[Finding]
    headers: Dict[str, str]

def parse_cookie_flags(set_cookie_header: str) -> Dict[str, Dict[str, bool]]:
    """
    Parse cookie attributes from a Set-Cookie header (best-effort).
    Returns a mapping: cookie_name -> flags dict.
    Note: Multi-cookie parsing is tricky due to commas in dates; this is a best-effort approach.
    """
    out: Dict[str, Dict[str, bool]] = {}
    if not set_cookie_header:
        return out

    # Split naively on comma+space, then try to load each part.
    # This won't be perfect for all cases, but works well for most simple cookies.
    parts = [p.strip() for p in set_cookie_header.split(", ")]
    for raw in parts:
        cookie = SimpleCookie()
        try:
            cookie.load(raw)
        except Exception:
            continue
        for name, morsel in cookie.items():
            samesite = (morsel["samesite"] or "").lower()
            out[name] = {
                "secure": bool(morsel["secure"]),
                "httponly": bool(morsel["httponly"]),
                "samesite_lax_or_strict": samesite in {"lax", "strict"},
            }
    return out

def analyze_headers(resp) -> List[Finding]:
    """
    Evaluate response headers for common security controls and leaks.
    """
    headers = {k: v for k, v in resp.headers.items()}
    findings: List[Finding] = []

    # Presence and basic value checks
    for name in SECURITY_HEADERS:
        present = name in headers
        if name == "X-XSS-Protection":
            msg = "Deprecated header present." if present else "Not present (deprecated, OK)."
            findings.append(Finding(name, True, "low", msg))
            continue

        if not present:
            sev = "high" if name in {"Content-Security-Policy", "Strict-Transport-Security"} else "medium"
            findings.append(Finding(name, False, sev, f"Missing {name} header."))
        else:
            value = headers[name].strip().lower()
            if name == "X-Content-Type-Options" and value != "nosniff":
                findings.append(Finding(name, False, "medium", f"{name} should be 'nosniff'."))
            elif name == "X-Frame-Options" and value not in {"deny", "sameorigin"}:
                findings.append(Finding(name, False, "medium", f"{name} should be 'DENY' or 'SAMEORIGIN'."))
            elif name == "Strict-Transport-Security" and "max-age" not in value:
                findings.append(Finding(name, False, "medium", "HSTS present but missing max-age."))
            else:
                findings.append(Finding(name, True, "info", "Present"))

    # Information leaks
    for leak in ("Server", "X-Powered-By"):
        if leak in headers:
            findings.append(Finding(leak, False, "low", f"Header {leak} reveals: {headers[leak]!r}. Consider removing."))

    # Cookies
    cookie_info = parse_cookie_flags(headers.get("Set-Cookie", ""))
    for cname, flags in cookie_info.items():
        if not flags.get("secure", False):
            findings.append(Finding(f"Cookie:{cname}", False, "high", "Cookie without Secure flag."))
        if not flags.get("httponly", False):
            findings.append(Finding(f"Cookie:{cname}", False, "medium", "Cookie without HttpOnly flag."))
        if not flags.get("samesite_lax_or_strict", False):
            findings.append(Finding(f"Cookie:{cname}", False, "medium", "Cookie without SameSite=Lax/Strict."))
    if cookie_info:
        findings.append(Finding("Cookies", True, "info", f"Checked {len(cookie_info)} cookies."))

    return findings

def http_get(url: str, timeout: int, verify: bool):
    try:
        resp = requests.get(
            url,
            allow_redirects=True,
            timeout=timeout,
            verify=verify,
            headers={"User-Agent": USER_AGENT},
        )
        return resp, None
    except Exception as e:
        return None, e

def scan_target(url: str, timeout: int = DEFAULT_TIMEOUT, verify: bool = True) -> ScanResult:
    start = time.time()
    resp, err = http_get(url, timeout, verify)
    elapsed = int((time.time() - start) * 1000)
    if err or resp is None:
        return ScanResult(
            url=url,
            status=None,
            final_url=None,
            https=url.lower().startswith("https"),
            redirects=0,
            elapsed_ms=elapsed,
            findings=[Finding("request", False, "high", f"Request error: {err}")],
            headers={},
        )
    https = urlparse(resp.url).scheme == "https"
    redirects = len(resp.history)
    findings = analyze_headers(resp)
    return ScanResult(
        url=url,
        status=resp.status_code,
        final_url=resp.url,
        https=https,
        redirects=redirects,
        elapsed_ms=elapsed,
        findings=findings,
        headers=dict(resp.headers),
    )

def scan_many(urls: List[str], workers: int, timeout: int, verify: bool) -> List[ScanResult]:
    results: List[ScanResult] = []
    with cf.ThreadPoolExecutor(max_workers=max(1, workers)) as ex:
        futs = [ex.submit(scan_target, u, timeout, verify) for u in urls]
        for fut in cf.as_completed(futs):
            results.append(fut.result())
    order = {u: i for i, u in enumerate(urls)}
    results.sort(key=lambda r: order.get(r.url, 10**9))
    return results

def to_pretty(results: List[ScanResult]) -> str:
    lines: List[str] = []
    for r in results:
        lines.append(f"URL: {r.url}")
        lines.append(f"Final: {r.final_url}  status={r.status}  https={r.https}  redirects={r.redirects}  {r.elapsed_ms}ms")
        lines.append("Findings:")
        for f in r.findings:
            mark = "✔" if f.ok else "✖"
            lines.append(f"  {mark} [{f.severity.upper()}] {f.key}: {f.message}")
        lines.append("")
    return "\n".join(lines).rstrip() + "\n"

def to_json(results: List[ScanResult]) -> str:
    payload = [{
        **{k: v for k, v in asdict(r).items() if k != "findings"},
        "findings": [asdict(f) for f in r.findings],
    } for r in results]
    return json.dumps(payload, indent=2, ensure_ascii=False) + "\\n"

def to_csv(results: List[ScanResult]) -> str:
    """
    Produce a wide CSV: one row per finding.
    Columns: url,status,final_url,https,redirects,elapsed_ms,finding_key,ok,severity,message
    """
    from io import StringIO
    buf = StringIO()
    writer = csv.writer(buf)
    writer.writerow(["url","status","final_url","https","redirects","elapsed_ms","finding_key","ok","severity","message"])
    for r in results:
        for f in r.findings:
            writer.writerow([r.url, r.status, r.final_url, r.https, r.redirects, r.elapsed_ms, f.key, f.ok, f.severity, f.message])
    return buf.getvalue()

def parse_args():
    p = argparse.ArgumentParser(description="Basic web header/misconfiguration scanner.")
    p.add_argument("target", nargs="?", help="One URL (e.g., https://example.com)")
    p.add_argument("--format", choices=["pretty", "json", "csv"], default="pretty", help="Output format (default: pretty)")
    p.add_argument("-o", "--output", help="Write results to a file instead of stdout")
    p.add_argument("-i", "--input", help="File with a list of URLs (one per line)")
    p.add_argument("-n", "--workers", type=int, default=4, help="Number of threads (default: 4)")
    p.add_argument("--timeout", type=int, default=DEFAULT_TIMEOUT, help="Timeout per request in seconds (default: 10)")
    p.add_argument("--no-verify", action="store_true", help="Do not verify SSL certificates (testing only)")
    return p.parse_args()

def main():
    args = parse_args()
    urls: List[str] = []
    if args.input:
        with open(args.input, "r", encoding="utf-8") as f:
            urls.extend([ln.strip() for ln in f if ln.strip() and not ln.strip().startswith("#")])
    if args.target:
        urls.append(args.target)
    if not urls:
        print("No targets. Provide a URL or -i file.", file=sys.stderr); sys.exit(2)

    results = scan_many(urls, args.workers, args.timeout, not args.no_verify)

    if args.format == "json":
        output_text = to_json(results)
    elif args.format == "csv":
        output_text = to_csv(results)
    else:
        output_text = to_pretty(results)

    if args.output:
        with open(args.output, "w", encoding="utf-8") as f:
            f.write(output_text)
    else:
        print(output_text, end="")

if __name__ == "__main__":
    main()
