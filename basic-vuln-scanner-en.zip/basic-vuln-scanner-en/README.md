# Basic Vulnerability Scanner 🔎🛡️

A small **CLI** tool (Python) that checks **HTTP security headers** and simple **misconfigurations** on websites.
This project is **English-only** (code, comments, README, tests).

## What it checks
- HTTPS usage and redirects count
- Security headers: `Strict-Transport-Security`, `Content-Security-Policy`, `X-Content-Type-Options`,
  `X-Frame-Options`, `Referrer-Policy`, `Permissions-Policy`, `X-XSS-Protection` (deprecated)
- Potential information leaks: `Server`, `X-Powered-By`
- Cookie flags: `Secure`, `HttpOnly`, `SameSite`
- Response time and final URL after redirects

> Note: This is a **static check** based on HTTP response headers and simple cookie parsing.
> It does **not** perform active scanning, fuzzing, or exploitation.

## Quick Start

```bash
python3 -m venv .venv
source .venv/bin/activate   # Windows: .venv\Scripts\activate
python -m pip install -U pip
pip install -r requirements.txt

# Single target (pretty text)
python src/vulnscan.py https://example.com

# JSON output to a file
python src/vulnscan.py https://example.com --format json -o report.json

# CSV output for many targets (concurrent)
python src/vulnscan.py -i urls.txt -n 5 --format csv -o report.csv
```

## Usage
```text
usage: vulnscan.py [-h] [--format {pretty,json,csv}] [-o OUTPUT] [-i INPUT]
                   [-n WORKERS] [--timeout TIMEOUT] [--no-verify]
                   [target]

Basic web header/misconfiguration scanner.

positional arguments:
  target                One URL (e.g., https://example.com)

options:
  -h, --help            show this help message and exit
  --format {pretty,json,csv}
                        Output format (default: pretty)
  -o, --output OUTPUT   Write results to a file instead of stdout
  -i, --input INPUT     File containing a list of URLs (one per line)
  -n, --workers WORKERS Number of threads for scanning (default: 4)
  --timeout TIMEOUT     Timeout (seconds) per request (default: 10)
  --no-verify           Do not verify SSL certificates (testing only)
```

## Project Structure
```
basic-vuln-scanner/
├── src/
│   └── vulnscan.py
├── tests/
│   └── test_analyzers.py
├── requirements.txt
├── LICENSE
├── README.md
└── .github/workflows/python.yml
```

## Security Notes
- Only scan domains you are **authorized** to test.
- Results are **indicative**; professional review is recommended for critical systems.
- `X-XSS-Protection` is deprecated; it is reported here for legacy awareness.
- `Content-Security-Policy` quality is not scored; only presence/basic sanity is checked.

## License
MIT
